package pe.edu.upeu.athenium.model;

public class Ejemplar {
    //Ejemplar: clean code - 001
}
