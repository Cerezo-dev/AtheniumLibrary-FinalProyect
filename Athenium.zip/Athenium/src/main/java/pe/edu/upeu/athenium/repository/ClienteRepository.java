package pe.edu.upeu.athenium.repository;

import pe.edu.upeu.athenium.model.Cliente;

public interface ClienteRepository extends ICrudGenericoRepository<Cliente,String>{
}
