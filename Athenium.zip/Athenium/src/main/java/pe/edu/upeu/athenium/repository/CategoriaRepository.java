package pe.edu.upeu.athenium.repository;

import pe.edu.upeu.athenium.model.Categoria;

public interface CategoriaRepository extends ICrudGenericoRepository <Categoria,Long>{
}
