package pe.edu.upeu.athenium.repository;


import pe.edu.upeu.athenium.model.Compra;

public interface CompraRepository extends ICrudGenericoRepository<Compra,Long>{
}
