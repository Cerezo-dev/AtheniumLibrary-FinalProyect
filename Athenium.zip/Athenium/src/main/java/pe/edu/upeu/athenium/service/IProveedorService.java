package pe.edu.upeu.athenium.service;

import pe.edu.upeu.athenium.model.Proveedor;

public interface IProveedorService extends  ICrudGenericoService<Proveedor,Long>{
}
