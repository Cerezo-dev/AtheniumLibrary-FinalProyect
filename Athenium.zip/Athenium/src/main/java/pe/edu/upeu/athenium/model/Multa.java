package pe.edu.upeu.athenium.model;

public class Multa {
}
