package pe.edu.upeu.athenium.service;

import pe.edu.upeu.athenium.model.Perfil;

public interface IPerfilService extends ICrudGenericoService<Perfil,Long>{
}
