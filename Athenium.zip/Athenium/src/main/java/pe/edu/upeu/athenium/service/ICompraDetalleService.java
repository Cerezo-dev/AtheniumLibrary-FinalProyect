package pe.edu.upeu.athenium.service;

import pe.edu.upeu.athenium.model.CompraDetalle;

public interface ICompraDetalleService extends ICrudGenericoService<CompraDetalle,Long>{
}
