package pe.edu.upeu.athenium.model;

public class Prestamo {
    //La transacción que une un Usuario con un Ejemplar
}
