package pe.edu.upeu.athenium.repository;


import pe.edu.upeu.athenium.model.Marca;

public interface MarcaRepository extends  ICrudGenericoRepository<Marca,Long>{
}
