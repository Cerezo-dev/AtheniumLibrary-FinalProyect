package pe.edu.upeu.athenium.repository;

import pe.edu.upeu.athenium.model.VentaDetalle;

public interface VentaDetalleRepository extends ICrudGenericoRepository<VentaDetalle,Long>{
}
