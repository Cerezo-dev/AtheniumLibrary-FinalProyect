package pe.edu.upeu.athenium.repository;

import pe.edu.upeu.athenium.model.Prestamo;

public interface PrestamoRepository extends  ICrudGenericoRepository<Prestamo,Long> {

}
