package pe.edu.upeu.athenium.repository;


import pe.edu.upeu.athenium.model.Venta;

public interface VentaRepository extends ICrudGenericoRepository<Venta,Long>{
}
