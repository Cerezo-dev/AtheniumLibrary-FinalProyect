package pe.edu.upeu.athenium.service;

import pe.edu.upeu.athenium.model.CompCarrito;

public interface ICompCarritoService extends ICrudGenericoService<CompCarrito,Long>{
}
