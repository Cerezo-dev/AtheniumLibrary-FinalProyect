package pe.edu.upeu.athenium.repository;


import pe.edu.upeu.athenium.model.UnidadMedida;

public interface UnidadMedidaRepository extends ICrudGenericoRepository<UnidadMedida,Long>{
}
