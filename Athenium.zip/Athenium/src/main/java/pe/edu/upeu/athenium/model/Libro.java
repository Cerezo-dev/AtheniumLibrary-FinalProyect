package pe.edu.upeu.athenium.model;

public class Libro {
    //Titulo: clean code
}
