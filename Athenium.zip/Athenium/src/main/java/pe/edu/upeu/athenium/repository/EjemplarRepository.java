package pe.edu.upeu.athenium.repository;

public interface EjemplarRepository {
}
