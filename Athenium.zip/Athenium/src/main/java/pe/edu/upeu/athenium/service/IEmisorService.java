package pe.edu.upeu.athenium.service;

import pe.edu.upeu.athenium.model.Emisor;

public interface IEmisorService extends  ICrudGenericoService<Emisor,Long>{
}
