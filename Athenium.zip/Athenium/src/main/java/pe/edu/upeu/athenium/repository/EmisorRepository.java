package pe.edu.upeu.athenium.repository;

import pe.edu.upeu.athenium.model.Emisor;

public interface EmisorRepository extends  ICrudGenericoRepository<Emisor,Long>{
}
