package pe.edu.upeu.athenium.service;

import pe.edu.upeu.athenium.model.VentaDetalle;

public interface IVentaDetalleService extends ICrudGenericoService<VentaDetalle,Long>{
}
