package pe.edu.upeu.athenium.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import pe.edu.upeu.athenium.model.Libro;

public interface LibroRepository extends JpaRepository<Libro,Integer> {
}
