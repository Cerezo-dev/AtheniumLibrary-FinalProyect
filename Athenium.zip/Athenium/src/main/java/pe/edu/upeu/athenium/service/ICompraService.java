package pe.edu.upeu.athenium.service;

import pe.edu.upeu.athenium.model.Compra;

public interface ICompraService extends ICrudGenericoService<Compra,Long>{
}
