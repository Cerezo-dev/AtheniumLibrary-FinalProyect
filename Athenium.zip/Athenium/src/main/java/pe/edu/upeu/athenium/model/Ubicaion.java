package pe.edu.upeu.athenium.model;

public class Ubicaion {

    //ESTO SERA OPCIONAL POR EL MOMENTO
    //Ubicación: estante A, fila 3
    //Nota: El nombre de la clase parece tener un error tipográfico. Debería ser "Ubicacion" en lugar de "Ubicaion".
    //(Para guardar "Piso 2, Estante B-05").
}
