package pe.edu.upeu.athenium.repository;

import pe.edu.upeu.athenium.model.Proveedor;

public interface ProveedorRepository extends ICrudGenericoRepository<Proveedor,Long>{
}
