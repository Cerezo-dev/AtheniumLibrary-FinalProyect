package pe.edu.upeu.athenium.enums;

public enum TipoDocumento {
    DNI,
    RUC;
}