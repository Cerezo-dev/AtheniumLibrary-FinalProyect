package pe.edu.upeu.athenium.repository;

import pe.edu.upeu.athenium.model.CompCarrito;

public interface CompCarritoRepository extends ICrudGenericoRepository<CompCarrito,Long>{
}
